# Python X11 Desktop

A minimal desktop environment built in Python using Xlib and PyQt5.
